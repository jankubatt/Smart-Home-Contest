# NAG-IoT
## -SPSUL-

### Seznamte se s Raspberry Pi a připojte ho do internetu.

1. Instalace systému<br>
    a. Stažení NOOBS<br>
    b. Formátování SD karty<br>
    c. Nahrát soubory ze ZIP složky na SD kartu<br>
    d. Vložit kartu do Raspberry Pi 3<br>
    e. Zapnout Raspberry Pi 3<br>
    f. Vybrat Raspbian a kliknout Instalovat<br>
<br>
2. Připojení do internetu<br>
    a. Do internetu se dá připojit pomocí wifi či Ethernet kabelu s koncovkou RJ-45