# NAG-IoT
## -Jméno týmu-

Video na git neumisťujte! <br />
Odkaz na video dle zadání: <br />
https://www.youtube.com...
