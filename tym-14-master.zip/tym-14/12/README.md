# NAG-IoT
## -Jméno týmu-

K tomuto bodu zadání není potřeba nic.
