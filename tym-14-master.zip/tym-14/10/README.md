# NAG-IoT
## -Jméno týmu-

Zde napiště postup při řešení úkolu dle zadání <br />
Včetně zdojů, použitých knihoven.
