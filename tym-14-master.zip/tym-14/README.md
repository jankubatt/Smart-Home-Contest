# NAG-IoT
## -SPSUL-

Úkoly: <br />

| Úloha | Splněno |
|-------|---------|
| 1. | ANO |
| 2. | ANO |
| 3. | ANO |
| 4. | ANO |
| 5. | ANO |
| 6. | ANO |
| 7. | ANO |
| 8. | ANO |
| 9. | ANO |
| 10. | ANO |
| 11. | NE |
| 12. | NE |

Video týmu je na adrese: <br />
https://www.youtube.com/watch?v=iWtRl39DOC8

